import { html, render } from "./node_modules/lit-html/lit-html.js";
search()

function search() {

   const root = document.getElementById("towns");
   const SearchButton = document.querySelector("button");


   SearchButton.addEventListener("click", OnSearchClick);


   function OnSearchClick(e) {

      let searchText = document.getElementById("searchText").value.trim();

      if (searchText) {

         const townsArray = searchText.split(',').map(town => town.trim());
         renderer(createTownList(townsArray));

      }

   }

   function createTownList(townsArray) {

      const AllTowns = html`
       <ul>
         ${townsArray.map(town => html`<li>${town}</li>`)}
      </ul>`;
      return AllTowns
   }


   function renderer(Alltowns) {

            // Get the current list from the root element
            const currentContent = root.innerHTML;

            // Create a temporary div to store the rendered newTowns content as HTML
            const tempDiv = document.createElement('div');
            render(Alltowns, tempDiv); // Render the new towns into tempDiv
      
            // Append the new list items to the existing content
            root.innerHTML = currentContent + tempDiv.innerHTML
   }

}