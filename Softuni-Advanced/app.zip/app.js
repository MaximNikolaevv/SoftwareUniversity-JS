import { html, render } from "./node_modules/lit-html/lit-html.js"
import { cats } from "./catSeeder.js"

const root = document.getElementById("allCats");

ForEveryCat(cats);

function ForEveryCat(cats) {
    let EveryCatInfo = html
        `<ul>
        ${cats.map(cat => (CreateCatList(cat)))}
        </ul>`

    render(EveryCatInfo, root)
}


function CreateCatList(cat) {
    let CurrCat = html`
<li>
    <img src="./images/${cat.imageLocation}.jpg" width="250" height="250" alt="Card image cap">
    <div class="info">
        <button class="showBtn">Show status code</button>
        <div class="status" style="display: none" id="${cat.id}">
            <h4>Status Code: ${cat.statusCode}</h4>
            <p>${cat.statusMessage}</p>
        </div>
    </div>
</li>`
    return CurrCat;
}


root.addEventListener("click", OnClick)

function OnClick(e) {

    if (e.target.classList.contains("showBtn")) {

        const statusDiv = e.target.parentElement.querySelector("div");

        if (statusDiv.style.display === "none" || statusDiv.style.display === "") {

            statusDiv.style.display = "block";
            e.target.textContent = "Hide status code";
        } else {

            statusDiv.style.display = "none";
            e.target.textContent = "Show status code";
        }
    }
}