import { html, render } from "./node_modules/lit-html/lit-html.js";
addItem();

function addItem() {
    const form = document.querySelector("form");
    const menu = document.getElementById("menu");
    let items = []; // This array will hold all items

    form.addEventListener("submit", onSubmit);

    function onSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const newItems = formData.get("itemText").split(", ").map(item => item.trim()).filter(item => item !== "");
        // Combine existing items with new items
        items = [...items, ...newItems]; // Use the spread operator to merge arrays
        const allItemLists = createItemList(items);
        renderer(allItemLists);
        form.reset(); // Reset the form after submission
    }

    function createItemList(itemList) {
        return html`
            ${itemList.map(item => html`<option>${item}</option>`)}
        `;
    }

    function renderer(allItemLists) {
        render(allItemLists, menu);
    }
}

