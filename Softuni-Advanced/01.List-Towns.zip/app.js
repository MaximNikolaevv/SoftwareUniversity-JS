import { html, render } from "./node_modules/lit-html/lit-html.js";

const form = document.querySelector("form").addEventListener("submit", OnSubmit);
const root = document.getElementById("root");

function OnSubmit(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const townslist = formData.get("towns").split(",");

    renderer(createTownList(townslist));

}

function createTownList(towns) {
    const AllTowns = html`
    <ul>
      ${towns.map(town => html`<li>${town}</li>`)} 
    </ul>
    `;

    return AllTowns;
}

function renderer(temp) {
    render(temp, root);
}
